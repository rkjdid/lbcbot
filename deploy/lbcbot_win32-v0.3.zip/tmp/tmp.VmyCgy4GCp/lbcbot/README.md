# lbcbot
watchbot for leboncoin.fr

```bash
go get github.com/rkjdid/lbcbot  // download
go install github.com/rkjdid/lbcbot // install
cp $GOPATH/github.com/rkjdid/lbcbot/config_sample.json config.json
# edit config.json to convenience
lbcbot -cfg config.json
```

